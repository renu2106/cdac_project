package com.trade.domain;

public enum WithdrawalStatus {
    PENDING,
    SUCCESS,
    DECLINE
}
