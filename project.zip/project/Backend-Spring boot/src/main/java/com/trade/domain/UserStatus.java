package com.trade.domain;

public enum UserStatus {

    VERIFIED,
    PENDING

}
