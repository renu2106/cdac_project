package com.trade.exception;

public class WalletException extends Exception {

    public WalletException(String message){
        super(message);
    }
}
