package com.trade.domain;

public enum PaymentMethod {
    RAZORPAY,
    STRIPE
}
