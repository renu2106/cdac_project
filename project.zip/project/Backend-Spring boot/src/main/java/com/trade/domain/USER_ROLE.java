package com.trade.domain;

public enum USER_ROLE {
    ROLE_ADMIN, ROLE_USER
}
