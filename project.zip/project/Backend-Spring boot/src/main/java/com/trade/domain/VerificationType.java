package com.trade.domain;

public enum VerificationType {
    MOBILE,
    EMAIL
}
