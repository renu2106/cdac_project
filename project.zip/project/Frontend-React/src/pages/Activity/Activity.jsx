import TreadingHistory from '../Portfilio/TreadingHistory'

const Activity = () => {
  return (
    <div className='px-20'>
      <p className='py-5 pb-10 text-2xl font-semibold'>Treading History</p>
        <TreadingHistory/>
    </div>
  )
}

export default Activity