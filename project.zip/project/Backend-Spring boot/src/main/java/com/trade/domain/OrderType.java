package com.trade.domain;

public enum OrderType {
    BUY,
    SELL
}
