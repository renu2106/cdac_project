package com.trade.domain;

public enum PaymentOrderStatus {
    PENDING,SUCCESS,FAILED
}
